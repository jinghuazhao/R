.onLoad <- function(lib, pkg)
{
    packageStartupMessage("kinship is loaded")
}

