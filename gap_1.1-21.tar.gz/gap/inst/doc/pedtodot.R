### R code from vignette source 'pedtodot.Rnw'

###################################################
### code chunk number 1: pedtodot.Rnw:32-36
###################################################
load("pedigrees.rda")
head(one,5)
head(two,5)
head(three,5)


###################################################
### code chunk number 2: pedtodot.Rnw:41-44 (eval = FALSE)
###################################################
## pedtodot(one, dir="forward")
## pedtodot(two, dir="forward")
## pedtodot(three,dir="forward")


